-- MySQL dump 10.13  Distrib 5.7.28, for Win64 (x86_64)
--
-- Host: localhost    Database: guardrail_monitoring
-- ------------------------------------------------------
-- Server version	5.7.28-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accidentevent`
--

DROP TABLE IF EXISTS `accidentevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accidentevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '아이디 번호',
  `guardrailID` int(11) NOT NULL COMMENT '가드레일 번호',
  `accidentDate` datetime NOT NULL COMMENT '사고 발생 시각',
  `accidentPlace` varchar(45) NOT NULL COMMENT '사고 발생 장소',
  `guardrailState` int(11) NOT NULL COMMENT '가드레일 상태',
  PRIMARY KEY (`id`),
  KEY `accidentevent_fk_1` (`guardrailState`),
  KEY `accidentevent_fk` (`guardrailID`),
  CONSTRAINT `accidentevent_fk` FOREIGN KEY (`guardrailID`) REFERENCES `guardrail` (`guardrailID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='사고 내역';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accidentevent`
--

LOCK TABLES `accidentevent` WRITE;
/*!40000 ALTER TABLE `accidentevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `accidentevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `areaID` int(11) NOT NULL AUTO_INCREMENT COMMENT '지역 번호',
  `cityprovinceCode` int(11) NOT NULL COMMENT '시도 코드',
  `cityprovinceName` varchar(45) NOT NULL COMMENT '시도 명',
  `districtCode` int(11) NOT NULL COMMENT '시군구 코드',
  `districtName` varchar(45) NOT NULL COMMENT '시군구 명',
  `emdCode` int(11) NOT NULL COMMENT '읍면동 코드',
  `emdName` varchar(45) NOT NULL COMMENT '읍면동 명',
  PRIMARY KEY (`areaID`),
  KEY `area_fk` (`cityprovinceCode`),
  KEY `area_fk_1` (`cityprovinceName`),
  KEY `area_fk_2` (`districtCode`),
  KEY `area_fk_3` (`districtName`),
  KEY `area_fk_4` (`emdCode`),
  KEY `area_fk_5` (`emdName`),
  CONSTRAINT `area_fk` FOREIGN KEY (`cityprovinceCode`) REFERENCES `cityprovince` (`cityprovinceCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `area_fk_1` FOREIGN KEY (`cityprovinceName`) REFERENCES `cityprovince` (`cityprovinceName`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `area_fk_2` FOREIGN KEY (`districtCode`) REFERENCES `district` (`districtCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `area_fk_4` FOREIGN KEY (`emdCode`) REFERENCES `emd` (`emdCode`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='지역';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,11,'서울특별시',11010,'종로구',1101053,'사직동');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cityprovince`
--

DROP TABLE IF EXISTS `cityprovince`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cityprovince` (
  `cityprovinceCode` int(11) NOT NULL AUTO_INCREMENT COMMENT '시도 코드',
  `cityprovinceName` varchar(45) NOT NULL COMMENT '시도 명',
  PRIMARY KEY (`cityprovinceCode`),
  UNIQUE KEY `cityprovince_un` (`cityprovinceName`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='시도';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cityprovince`
--

LOCK TABLES `cityprovince` WRITE;
/*!40000 ALTER TABLE `cityprovince` DISABLE KEYS */;
INSERT INTO `cityprovince` VALUES (11,'서울특별시');
/*!40000 ALTER TABLE `cityprovince` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `districtCode` int(11) NOT NULL AUTO_INCREMENT COMMENT '시군구 코드',
  `districtName` varchar(45) NOT NULL COMMENT '시군구 명',
  PRIMARY KEY (`districtCode`)
) ENGINE=InnoDB AUTO_INCREMENT=11012 DEFAULT CHARSET=utf8 COMMENT='시군구';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` VALUES (11010,'종로구'),(11011,'종로구');
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emd`
--

DROP TABLE IF EXISTS `emd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emd` (
  `emdCode` int(11) NOT NULL AUTO_INCREMENT COMMENT '읍면동 코드',
  `emdName` varchar(45) NOT NULL COMMENT '읍면동 명',
  PRIMARY KEY (`emdCode`)
) ENGINE=InnoDB AUTO_INCREMENT=1101054 DEFAULT CHARSET=utf8 COMMENT='읍면동';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emd`
--

LOCK TABLES `emd` WRITE;
/*!40000 ALTER TABLE `emd` DISABLE KEYS */;
INSERT INTO `emd` VALUES (11,'사직동'),(1101053,'사직동');
/*!40000 ALTER TABLE `emd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guardrail`
--

DROP TABLE IF EXISTS `guardrail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guardrail` (
  `guardrailID` int(11) NOT NULL COMMENT '가드레일 번호',
  `roadCode` int(11) NOT NULL COMMENT '도로명 코드',
  `cityprovinceCode` int(11) NOT NULL COMMENT '시도 코드',
  `districtCode` int(11) NOT NULL COMMENT '시군구 코드',
  `emdCode` int(11) NOT NULL COMMENT '읍면동 코드',
  `guardrailState` int(11) NOT NULL COMMENT '가드레일 상태',
  `guardrailLongitude` double NOT NULL COMMENT '가드레일 경도 좌표',
  `guardrailLatitude` double NOT NULL COMMENT '가드레일 위도 좌표',
  PRIMARY KEY (`guardrailID`),
  KEY `guardrail_fk` (`cityprovinceCode`),
  KEY `guardrail_fk_1` (`districtCode`),
  KEY `guardrail_fk_2` (`emdCode`),
  KEY `guardrail_fk_3` (`roadCode`),
  CONSTRAINT `guardrail_fk` FOREIGN KEY (`cityprovinceCode`) REFERENCES `cityprovince` (`cityprovinceCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `guardrail_fk_1` FOREIGN KEY (`districtCode`) REFERENCES `district` (`districtCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `guardrail_fk_2` FOREIGN KEY (`emdCode`) REFERENCES `emd` (`emdCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `guardrail_fk_3` FOREIGN KEY (`roadCode`) REFERENCES `road` (`roadCode`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='가드레일';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guardrail`
--

LOCK TABLES `guardrail` WRITE;
/*!40000 ALTER TABLE `guardrail` DISABLE KEYS */;
/*!40000 ALTER TABLE `guardrail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `road`
--

DROP TABLE IF EXISTS `road`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `road` (
  `roadCode` int(11) NOT NULL AUTO_INCREMENT COMMENT '도로명 코드',
  `roadName` varchar(45) NOT NULL COMMENT '도로명',
  `cityprovinceCode` int(11) NOT NULL COMMENT '시도 코드',
  `districtCode` int(11) NOT NULL COMMENT '시군구 코드',
  `startPointX` double NOT NULL,
  `startPointY` double NOT NULL,
  `endPointX` double NOT NULL,
  `endPointY` double NOT NULL,
  `emdCode` int(11) NOT NULL COMMENT '읍면동 코드',
  PRIMARY KEY (`roadCode`),
  KEY `road_fk` (`cityprovinceCode`),
  KEY `road_fk_1` (`districtCode`),
  KEY `road_fk_2` (`emdCode`),
  CONSTRAINT `road_fk` FOREIGN KEY (`cityprovinceCode`) REFERENCES `cityprovince` (`cityprovinceCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `road_fk_1` FOREIGN KEY (`districtCode`) REFERENCES `district` (`districtCode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `road_fk_2` FOREIGN KEY (`emdCode`) REFERENCES `emd` (`emdCode`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3100006 DEFAULT CHARSET=utf8 COMMENT='도로';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `road`
--

LOCK TABLES `road` WRITE;
/*!40000 ALTER TABLE `road` DISABLE KEYS */;
/*!40000 ALTER TABLE `road` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'guardrail_monitoring'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-05 22:35:24
